class RubiksCube {
  constructor() {
    this.reset();
  }

  reset() {
    this.faces = {
      U: Array(9).fill('w'),
      D: Array(9).fill('y'),
      F: Array(9).fill('g'),
      B: Array(9).fill('b'),
      L: Array(9).fill('o'),
      R: Array(9).fill('r'),
    };
    this.scrambleMoves = [];
  }

  rotateFace(face) {
    const f = this.faces[face];
    this.faces[face] = [f[6], f[3], f[0], f[7], f[4], f[1], f[8], f[5], f[2]];
  }

  rotateFrontClockwise() {
    this.rotateFace('F');
    const U = this.faces.U, R = this.faces.R, D = this.faces.D, L = this.faces.L;
    const temp = [U[6], U[7], U[8]];
    [U[6], U[7], U[8]] = [L[8], L[5], L[2]];
    [L[2], L[5], L[8]] = [D[2], D[1], D[0]];
    [D[0], D[1], D[2]] = [R[6], R[3], R[0]];
    [R[0], R[3], R[6]] = temp;
  }

  rotateUpClockwise() {
    this.rotateFace('U');
    const B = this.faces.B, R = this.faces.R, F = this.faces.F, L = this.faces.L;
    const temp = [B[0], B[1], B[2]];
    [B[0], B[1], B[2]] = [R[0], R[1], R[2]];
    [R[0], R[1], R[2]] = [F[0], F[1], F[2]];
    [F[0], F[1], F[2]] = [L[0], L[1], L[2]];
    [L[0], L[1], L[2]] = temp;
  }

  rotateDownClockwise() {
    this.rotateFace('D');
    const F = this.faces.F, R = this.faces.R, B = this.faces.B, L = this.faces.L;
    const temp = [F[6], F[7], F[8]];
    [F[6], F[7], F[8]] = [L[6], L[7], L[8]];
    [L[6], L[7], L[8]] = [B[6], B[7], B[8]];
    [B[6], B[7], B[8]] = [R[6], R[7], R[8]];
    [R[6], R[7], R[8]] = temp;
  }

  rotateLeftClockwise() {
    this.rotateFace('L');
    const U = this.faces.U, F = this.faces.F, D = this.faces.D, B = this.faces.B;
    const temp = [U[0], U[3], U[6]];
    [U[0], U[3], U[6]] = [B[8], B[5], B[2]];
    [B[8], B[5], B[2]] = [D[0], D[3], D[6]];
    [D[0], D[3], D[6]] = [F[0], F[3], F[6]];
    [F[0], F[3], F[6]] = temp;
  }

  rotateRightClockwise() {
    this.rotateFace('R');
    const U = this.faces.U, B = this.faces.B, D = this.faces.D, F = this.faces.F;
    const temp = [U[2], U[5], U[8]];
    [U[2], U[5], U[8]] = [F[2], F[5], F[8]];
    [F[2], F[5], F[8]] = [D[2], D[5], D[8]];
    [D[2], D[5], D[8]] = [B[6], B[3], B[0]];
    [B[6], B[3], B[0]] = temp;
  }

  rotateBackClockwise() {
    this.rotateFace('B');
    const U = this.faces.U, L = this.faces.L, D = this.faces.D, R = this.faces.R;
    const temp = [U[0], U[1], U[2]];
    [U[0], U[1], U[2]] = [R[2], R[5], R[8]];
    [R[2], R[5], R[8]] = [D[8], D[7], D[6]];
    [D[6], D[7], D[8]] = [L[0], L[3], L[6]];
    [L[0], L[3], L[6]] = temp;
  }

  scramble(moves = 20) {
    const rotations = [
      'rotateFrontClockwise', 'rotateBackClockwise', 'rotateLeftClockwise',
      'rotateRightClockwise', 'rotateUpClockwise', 'rotateDownClockwise'
    ];
    this.scrambleMoves = [];
    for (let i = 0; i < moves; i++) {
      const move = rotations[Math.floor(Math.random() * rotations.length)];
      this[move]();
      this.scrambleMoves.push(move);
    }
  }

  solve() {
    for (let i = this.scrambleMoves.length - 1; i >= 0; i--) {
      const move = this.scrambleMoves[i];
      for (let j = 0; j < 3; j++) {
        this[move]();
      }
    }
  }

  getCubeString() {
    return (
      this.faces.U.join('') +
      this.faces.R.join('') +
      this.faces.F.join('') +
      this.faces.D.join('') +
      this.faces.L.join('') +
      this.faces.B.join('')
    );
  }
}

function getCubeSvg(cubeStr) {
  const colors = {
    r: '#ff0000', g: '#00ff00', b: '#0000ff',
    y: '#ffff00', o: '#ffa500', w: '#ffffff'
  };

  function createFaceHTML(faceStr) {
    return `<div style="display:grid;grid-template-columns:repeat(3,30px);margin:5px;">
      ${[...faceStr].map(c => `<div style="width:30px;height:30px;background:${colors[c]};border:1px solid #000;"></div>`).join('')}
    </div>`;
  }

  const [U, R, F, D, L, B] = [
    cubeStr.slice(0,9), cubeStr.slice(9,18), cubeStr.slice(18,27),
    cubeStr.slice(27,36), cubeStr.slice(36,45), cubeStr.slice(45,54)
  ];

  return `
    <div style="display:flex;flex-direction:column;align-items:center;">
      ${createFaceHTML(U)}
      <div style="display:flex;">
        ${createFaceHTML(L)}
        ${createFaceHTML(F)}
        ${createFaceHTML(R)}
        ${createFaceHTML(B)}
      </div>
      ${createFaceHTML(D)}
    </div>
  `;
}

const cube = new RubiksCube();

function displayCube() {
  const cubeStr = cube.getCubeString();
  document.getElementById('cube-display').innerHTML = getCubeSvg(cubeStr);
}

function updateMoves(isSolved = false) {
  const moveLog = document.getElementById('move-log');
  if (isSolved) {
    moveLog.textContent = cube.scrambleMoves.map(m => m + "'").join(', ') + ' (reversed)';
  } else if (cube.scrambleMoves.length > 0) {
    moveLog.textContent = cube.scrambleMoves.join(', ');
  } else {
    moveLog.textContent = 'None';
  }
}

displayCube();

